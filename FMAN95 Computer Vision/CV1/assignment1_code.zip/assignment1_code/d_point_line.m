function d = d_point_line(point,line);
%DISTANCE Summary of this function goes here
%   Detailed explanation goes here
a = line(1);
b = line(2);
c = line(3);

x = point(1);
y = point(2);
z = point(3);

d = abs(a*x+b*y+c)/sqrt(a^2 + b^2);
