clear all
clc
%% Computer Exercise-1 Points in Homogeneous Coordinates
% Load datasets - 'compEx1.mat'
load('compEx1.mat');

% Calculated with the pflat function
x2D_ = pflat(x2D);
x3D_ = pflat(x3D);

% Plotting the results
figure(1)
subplot(1,2,1);
plot(x2D_(1,:), x2D_(2,:),'.');
title('Subplot 1: x2D_')
subplot(1,2,2);
plot3(x3D_(1,:), x3D_(2,:),x3D_(3,:),'.');
title('Subplot 2: x3D_')
axis equal

%% Computer Exercise-2 Lines
% Load and Plot - 'compEx2.jpg','compEx2.mat'
load('compEx2.mat');

im = imread('compEx2.JPG');
% imshow(im)
figure(2)
imagesc(im)
colormap gray

% Plot three pairs of image points in the same figure
hold on;
plot(p1(1,:),p1(2,:),'*',p2(1,:),p2(2,:),'o',p3(1,:),p3(2,:),'x','MarkerSize',6,'LineWidth',2)

% Compute the lines
l_1 = null(p1');
l_2 = null(p2');
l_3 = null(p3');

% Plot the lines
hold on;
rital(l_1);
rital(l_2);
rital(l_3);

% Compute the intersection of second and third line
x_ = null([l_2 l_3]');
x_ = pflat(x_);
hold on;
plot(x_(1,:),x_(2,:),'+','MarkerSize',6,'LineWidth',5)

% Compute the distance
d =  d_point_line(x_,l_1);
ANS = ['Distance:',num2str(d)];
disp('Computer Exercise 02:')
disp(ANS)
%% Computer Exercise-3 Projective Transformations
% Load datasets - 'compEx3.mat'
load('compEx3.mat');

% Plot the grid
figure(3)
plot([startpoints(1,:); endpoints(1,:)], ...
    [startpoints(2,:); endpoints(2,:)],'b-');

H1 = [sqrt(3) -1 1; 1 sqrt(3) 1; 0 0 2];
H2 = [1 -1 1; 1 1 0; 0 0 1];
H3 = [1 1 0; 0 2 0; 0 0 1];
H4 = [sqrt(3) -1 1; 1 sqrt(3) 1; 1/4 1/2 2];

[r,c] = size(startpoints);
ones_ = ones(1,c);
startpoints_ = [startpoints;ones_];
endpoints_ = [endpoints;ones_];

% Euclidean Transformations - Preserves distances between points
figure(4)
H1_start = pflat(H1 * startpoints_);
H1_end = pflat(H1 * endpoints_);
subplot(2,2,1);
plot([H1_start(1,:); H1_end(1,:)], ...
    [H1_start(2,:); H1_end(2,:)],'b-');
axis equal
title('Subplot 1: Euclidean Transformations')

% Similarity Transformations - Preserves Angles between Lines
subplot(2,2,2);
H2_start = pflat(H2 * startpoints_);
H2_end = pflat(H2 * endpoints_);
plot([H2_start(1,:); H2_end(1,:)], ...
    [H2_start(2,:); H2_end(2,:)],'b-');
title('Subplot 2: Similarity Transformations')

% Affine Transformations - Preserves Parallel Lines
subplot(2,2,3);
H3_start = pflat(H3 * startpoints_);
H3_end = pflat(H3 * endpoints_);
plot([H3_start(1,:); H3_end(1,:)], ...
    [H3_start(2,:); H3_end(2,:)],'b-');
axis equal
title('Subplot 3: Affine Transformations')

% Projective Transformations
subplot(2,2,4);
H4_start = pflat(H4 * startpoints_);
H4_end = pflat(H4 * endpoints_);
plot([H4_start(1,:); H4_end(1,:)], ...
    [H4_start(2,:); H4_end(2,:)],'b-');
axis equal
title('Subplot 4: Projective Transformations')

%% Computer Exercise-4 The Pinhole Camera
% Load and plot 'compEx4.mat','compEx4im1.jpg','compExim2.jpg'
load('compEx4.mat');
im1 = imread('compEx4im1.jpg');
im2 = imread('compEx4im2.jpg');
figure(5)
subplot(1,2,1);
imagesc(im1)
colormap gray
title('Subplot 1: compEx4im1.jpg')
hold on;
subplot(1,2,2);
imagesc(im2)
colormap gray
title('Subplot 2: compEx4im2.jpg')
hold on;

% Compute the camera center and the principal axis
camera_center1 = null(K * [R1 t1]);
camera_center1 = pflat(camera_center1);
camera_center2 = null(K * [R2 t2]);
camera_center2 = pflat(camera_center2);
K_R1 = K * R1;
K_R2 = K * R2;
viewing_direction1 = pflat(K_R1(3,:)');
viewing_direction2 = pflat(K_R2(3,:)');

% Plot the 3D-points in U and the camera centers
figure(6)
U = pflat(U);
plot3(U(1,:),U(2,:),U(3,:),'.');
hold on;
quiver3(camera_center1(1),camera_center1(2),camera_center1(3),viewing_direction1(1),viewing_direction1(2),viewing_direction1(3),2,'LineWidth',3);
quiver3(camera_center2(1),camera_center2(2),camera_center2(3),viewing_direction2(1),viewing_direction2(2),viewing_direction2(3),15,'LineWidth',3);

% Project U into P1, P2
projection1 = pflat((K * [R1 t1])*U);
projection2 = pflat((K * [R2 t2])*U);
figure(7)
subplot(1,2,1);
imagesc(im1)
colormap gray
hold on
plot(projection1(1,:),projection1(2,:),'.','Markersize',2);

subplot(1,2,2);
imagesc(im2)
colormap gray
hold on
plot(projection2(1,:),projection2(2,:),'.','Markersize',2);

%% Computer Exercise-5 Optional
% Plot the corner points and the image
load('CompEx5.mat');
im_5 = imread('CompEx5.jpg');
figure(8)
imagesc(im_5)
colormap gray

hold on
plot(corners(1,[1:end 1]), corners(2,[1:end 1]),'*-','Markersize',7,'LineWidth',2);

% Calibrated Cameras
% [r,c] = size(corners);
% ones_ = ones(1,c);
% corners_ = [corners;ones_];
% corners_ = (inv(K))*K*Rt*corners_;
corners_ = (inv(K)*corners);
figure(9)
plot(corners_(1,[1:end 1]), corners_(2,[1:end 1]),'*-','Markersize',7,'LineWidth',2)
axis ij

% Compute the camera centera and principal axis
figure(10)
plot3(v(1,:),v(2,:),v(3,:),'o','Markersize',7);

v_ = pflat(v);
v_ = -v_((1:3),:);
s = v_' * corners_;
corners_3D = pflat([corners_;s]);
hold on
plot3(corners_3D(1,:),corners_3D(2,:),corners_3D(3,:),'x','Markersize',7)
Rt = [1 0 0 0;0 1 0 0;0 0 1 0];
cc_5 = null(Rt);
pa_5 = Rt(3,(1:3))';
hold on
quiver3(cc_5(1),cc_5(2),cc_5(3),pa_5(1),pa_5(2),pa_5(3),2,'LineWidth',3);

Rt_2 = [sqrt(3)/2 0 1/2; 0 1 0; -(1/2) 0 sqrt(3)/2];
cc_5_2 = [2 0 0] * Rt_2';
pa_5_2 = Rt_2(3,:)';
hold on
quiver3(cc_5_2(1),cc_5_2(2),cc_5_2(3),pa_5_2(1),pa_5_2(2),pa_5_2(3),2,'LineWidth',3);

% Compute the homography
H_5 = (Rt_2 - [0;0;0]*v_');
y_ = pflat(H_5 * corners_3D((1:3),:));
figure(11)
plot(y_(1,[1:end 1]), y_(2,[1:end 1]),'*-','Markersize',7,'LineWidth',2);
